package application;

public class PageAdmin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	int id;
	String hotel,date,guest,email,mobile,room,price,account,accountEmail,blocked;
	public String getBlocked() {
		return blocked;
	}
	public void setBlocked(String blocked) {
		this.blocked = blocked;
	}
	public int getId() {
		return id;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getAccountEmail() {
		return accountEmail;
	}
	public void setAccountEmail(String accountEmail) {
		this.accountEmail = accountEmail;
	}
	public PageAdmin(int id, String hotel, String date, String guest, String email, String mobile, String room,
			String price, String account, String accountEmail,String blocked) {
		this.id = id;
		this.hotel = hotel;
		this.date = date;
		this.guest = guest;
		this.email = email;
		this.mobile = mobile;
		this.room = room;
		this.price = price;
		this.account = account;
		this.accountEmail = accountEmail;
		this.blocked = blocked;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHotel() {
		return hotel;
	}
	public void setHotel(String hotel) {
		this.hotel = hotel;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getGuest() {
		return guest;
	}
	public void setGuest(String guest) {
		this.guest = guest;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
//	int id;
//	String username,password,email,type;
//	
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getUsername() {
//		return username;
//	}
//
//	public void setUsername(String username) {
//		this.username = username;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	public String getType() {
//		return type;
//	}
//
//	public void setType(String type) {
//		this.type = type;
//	}
//
//	public PageAdmin(int id, String username, String password, String email, String type) {
//		
//		this.id = id;
//		this.username = username;
//		this.password = password;
//		this.email = email;
//		this.type = type;
//	}

}
