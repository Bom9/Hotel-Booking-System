package application;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class adminPageSQL {
	Connection conn = null;
	
	
	
	public static Connection ConnectDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		
    		return conn;
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
	
	
	public static ObservableList<PageAdmin> getDatausers(){
		
		Connection conn = ConnectDB();
		ObservableList<PageAdmin> list = FXCollections.observableArrayList();
		
		try {
			
			PreparedStatement ps = conn.prepareStatement("select * from confirmedbooking");
			
			ResultSet rs = ps.executeQuery();
			int b =0;
			String blocked ="No";
			while(rs.next()) {
				String name = rs.getString("accountName");
				PreparedStatement ps2 = conn.prepareStatement("select * from login where name = ?");
				ps2.setString(1, name);
				ResultSet rs2 = ps2.executeQuery();
				rs2.next();
				if(rs2.getInt("blocklist")==1)
					blocked="Yes";
				
	            
				list.add(new PageAdmin(rs.getInt("id"),rs.getString("hotelName"),rs.getString("date"),
						rs.getString("guestName"),rs.getString("email"),rs.getString("mobile"),rs.getString("roomType"),
						rs.getString("price"),rs.getString("accountName"),rs.getString("accountEmail"),blocked));
				b++;
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}
}
