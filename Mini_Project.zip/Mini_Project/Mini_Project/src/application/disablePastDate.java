package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JOptionPane;

import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.util.Callback;


public class disablePastDate {
	private static Connection conn=null;
	private static ResultSet rs = null;
	private static PreparedStatement pst=null;
	private static int abc[][] = new int[4][10];

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static void disable(DatePicker date) {
		date.setDayCellFactory(picker -> new DateCell() {
	        public void updateItem(LocalDate date, boolean empty) {
	            super.updateItem(date, empty);
	            LocalDate today = LocalDate.now();

	            setDisable(empty || date.compareTo(today) < 0 );
	        }
	    });
		
	}
	
//	public static DatePicker getDatePicker(List<LocalDate> disabledDays) {
//        final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {
//            @Override
//            public DateCell call(final DatePicker datePicker) {
//                return new DateCell() {
//                    @Override
//                    public void updateItem(LocalDate item, boolean empty) {
//                        super.updateItem(item, empty);
//
//                        if (disabledDays.contains(item)) {
//                            setDisable(true);
//                            setStyle("-fx-background-color: #ffc0cb;");
//                        }
//                    }
//                };
//            }
//        };
//        final DatePicker datePicker = new DatePicker();
//        datePicker.setDayCellFactory(dayCellFactory);
//
//        return datePicker;
//    }
//
//    public static void specific(DatePicker dateaa) {
//    	int[][] disabledDayArr = {{2023, 2, 9}, {2023, 2, 10}, {2023, 2, 11}};
//    	List<LocalDate> disabledDays = new ArrayList<>();
//        for (int[] day : disabledDayArr) {
//            disabledDays.add(LocalDate.of(day[0], day[1], day[2]));
//        	System.out.println(day[0]+" "+day[1]+" "+day[2]);
//        }
//        DatePicker dateaaa = getDatePicker(disabledDays);
//        dateaaa.show();
//        // add datePicker to the scene or container
//    }
//    public static void checkInDays(DatePicker dateaa) {
//    	int day[] = null,month[] = null,year[] = null;
//    	
//    	
//    	try {
//    		conn = adminPageSQL.ConnectDB();
//    		Statement stmt = conn.createStatement();
//    		String sql = "select * from parkroyalbooking";
//    		ResultSet rs=stmt.executeQuery(sql);
//    		JOptionPane.showMessageDialog(null, "connectd");
//    		int i =0;
//    		while(rs.next()) {
//    			String date = rs.getString("checkIn");
//    			
//    			abc[i][0]=Integer.parseInt(date.substring(7,11)); //year
//    			abc[i][1]=getMonth(date.substring(0,3)); //month
//    			abc[i][2]=Integer.parseInt(date.substring(4,6)); //day
//    			i++;
//    		}
//    		
//    	}catch (Exception e) {
//			// TODO: handle exception
//    		JOptionPane.showMessageDialog(null, e);
//		}
//    	specific(dateaa);
//    }
//    
//    public static int getMonth(String m) {
//    	int month=0;
//    	switch(m) {
//    	case "Jan":month=1;break;
//    	case "Feb":month=2;break;
//    	case "Mar":month=3;break;
//    	case "Apr":month=4;break;
//    	case "May":month=5;break;
//    	case "Jun":month=6;break;
//    	case "Jul":month=7;break;
//    	case "Aug":month=8;break;
//    	case "Sep":month=9;break;
//    	case "Oct":month=10;break;
//    	case "Nov":month=11;break;
//    	case "Dec":month=12;break;
//    	
//    	}
//    	return month;
//    }

}
