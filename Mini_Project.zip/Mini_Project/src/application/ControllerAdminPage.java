package application;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import javax.mail.FetchProfile.Item;
import javax.swing.JOptionPane;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ControllerAdminPage implements Initializable{
	
    @FXML
    private TextField filterField;
    
    @FXML
    private TextField txt_accountEmail;

    @FXML
    private TextField txt_accountName;
	
    @FXML
    private DatePicker txt_checkIn;

    @FXML
    private DatePicker txt_checkOut;

    @FXML
    private TextField txt_email;

    @FXML
    private TextField txt_guest;

    @FXML
    private ChoiceBox<String> txt_hotel;

    @FXML
    private TextField txt_id;

    @FXML
    private TextField txt_mobile;

    @FXML
    private TextField txt_price;

    @FXML
    private ChoiceBox<String> txt_room;
    
    @FXML
    private TableColumn<PageAdmin, String> col_block;


    @FXML
    private TableColumn<PageAdmin, Integer> col_id;

    @FXML
    private TableColumn<PageAdmin, String> col_account;

    @FXML
    private TableColumn<PageAdmin, String> col_accountEmail;

    @FXML
    private TableColumn<PageAdmin, String> col_date;

    @FXML
    private TableColumn<PageAdmin, String> col_email;

    @FXML
    private TableColumn<PageAdmin, String> col_guest;

    @FXML
    private TableColumn<PageAdmin, String> col_hotel;

    @FXML
    private TableColumn<PageAdmin, String> col_mobile;

    @FXML
    private TableColumn<PageAdmin, String> col_price;

    @FXML
    private TableColumn<PageAdmin, String> col_room;

    @FXML
    private TableView<PageAdmin> table_users;
    
    ObservableList<PageAdmin> listM;
    ObservableList<PageAdmin> dataList ;
    
    
    int index=-1;
    Connection conn=null;
    ResultSet rs = null;
    PreparedStatement pst=null;
    private static String checkInDate,checkOutDate,conbinedDate;
    private static LocalDate firstDate,secDate;
//    public static String allNameInTable[];
    
    public void Add_users() {
    	//conn = adminPageSQL.ConnectDB();
    	conn = sqlConnection.ConnectDB();
    	String sql = "insert into confirmedbooking (hotelName,date,guestName,email,mobile,roomType,price,accountName,accountEmail)values(?,?,?,?,?,?,?,?,?)";
    	try {
    		pst = conn.prepareStatement(sql);
    		pst.setString(1, txt_hotel.getSelectionModel().getSelectedItem());
    		getDate();
    		System.out.println(conbinedDate);
    		pst.setString(2, conbinedDate);
    		pst.setString(3, txt_guest.getText());
    		pst.setString(4, txt_email.getText());
    		pst.setString(5, txt_mobile.getText());
    		pst.setString(6, txt_room.getSelectionModel().getSelectedItem());
    		pst.setString(7, txt_price.getText());
    		pst.setString(8, txt_accountName.getText());
    		pst.setString(9, txt_accountEmail.getText());
    		pst.execute();
    		
    		JOptionPane.showMessageDialog(null, "Added successully");
    		UpdateTable();
    		//serach_user();
    	}catch(Exception e) {
    		JOptionPane.showMessageDialog(null, e);
    	}
    }
    
    @FXML
    void getSelected(MouseEvent event) {
    	index = table_users.getSelectionModel().getSelectedIndex();
    	if(index<=-1) {
    		return;
    	}
    	
    	decodeDateFromSQL(index);
    	
    	txt_id.setText(col_id.getCellData(index).toString());
    	txt_hotel.setValue(col_hotel.getCellData(index).toString());
    	txt_checkIn.setValue(firstDate);
    	txt_checkOut.setValue(secDate);
    	txt_guest.setText(col_guest.getCellData(index).toString());
    	txt_email.setText(col_email.getCellData(index).toString());
    	txt_mobile.setText(col_mobile.getCellData(index).toString());
    	txt_room.setValue(col_room.getCellData(index).toString());
    	txt_price.setText(col_price.getCellData(index).toString());
    	txt_accountName.setText(col_account.getCellData(index).toString());
    	txt_accountEmail.setText(col_accountEmail.getCellData(index).toString());
    	
    	
    	
    	
    }
    
    public void Edit() {
    	try {
    		getDate();
//    		conn = adminPageSQL.ConnectDB();
    		conn = sqlConnection.ConnectDB();
    		String value1 = txt_id.getText();
    		String value2 = txt_hotel.getSelectionModel().getSelectedItem();
    		String value3 = conbinedDate;
    		String value4 = txt_guest.getText();
    		String value5 = txt_email.getText();
    		String value6 = txt_room.getSelectionModel().getSelectedItem();
    		String value7 = txt_price.getText();
    		String value8 = txt_accountName.getText();
    		String value9 = txt_accountEmail.getText();
    		
    		String sql = "update confirmedbooking set id= '"+value1+"',hotelName= '"+value2+"',date= '"+
    				value3+"',guestName= '"+value4+"',email= '"+value5+"',mobile= '"+
    				value5+"',roomType= '"+value6+"',price= '"+value7+"',accountName= '"+
    				value8+"',accountEmail= '"+value9+"'where id='"+value1+"'";
    		pst = conn.prepareStatement(sql);
    		pst.execute();
    		
    		JOptionPane.showMessageDialog(null, "Updated successully");
    		UpdateTable();
    		//serach_user();
    	}catch(Exception e) {
    		JOptionPane.showMessageDialog(null, e);
    	}
    }
    
    public void Delete() {
//    	conn = adminPageSQL.ConnectDB();
    	conn = sqlConnection.ConnectDB();
    	try {
			PreparedStatement pst = conn.prepareStatement("UPDATE login SET booked=? WHERE name LIKE ?");
			index = table_users.getSelectionModel().getSelectedIndex();
			pst.setInt(1, 0);
			pst.setString(2, col_account.getCellData(index).toString());
			pst.executeUpdate();
    	}catch(Exception e) {
    		System.out.println(e);
    	}
		
    	String sql = "delete from confirmedbooking where id=?";
    	try {
    		pst = conn.prepareStatement(sql);
    		pst.setString(1, txt_id.getText());
    		pst.execute();
    		JOptionPane.showMessageDialog(null, "Check out successully");
    		UpdateTable();
    		
    		//serach_user();
    	}catch (Exception e) {
			// TODO: handle exception
    		JOptionPane.showMessageDialog(null, e);
		}
    }
    

    @FXML
    void Block(ActionEvent event) {
//    	conn = adminPageSQL.ConnectDB();
    	conn = sqlConnection.ConnectDB();
    	try {
			PreparedStatement pst = conn.prepareStatement("update login SET blocklist=? WHERE name LIKE ?");
			index = table_users.getSelectionModel().getSelectedIndex();
			pst.setInt(1, 1);
			pst.setString(2, col_account.getCellData(index).toString());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Blocked successully");
			UpdateTable();
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
    
    @FXML
    void unblock(ActionEvent event) {
//    	conn = adminPageSQL.ConnectDB();
    	conn = sqlConnection.ConnectDB();
    	try {
			PreparedStatement pst = conn.prepareStatement("update login SET blocklist=? WHERE name LIKE ?");
			index = table_users.getSelectionModel().getSelectedIndex();
			pst.setInt(1, 0);
			pst.setString(2, col_account.getCellData(index).toString());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Unblock successully");
			UpdateTable();
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
    
    public void UpdateTable() {
    	col_id.setCellValueFactory(new PropertyValueFactory<PageAdmin,Integer>("id"));
		col_hotel.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("hotel"));
		col_date.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("date"));
		col_guest.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("guest"));
		col_email.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("email"));
		
		col_mobile.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("mobile"));
		col_room.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("room"));
		col_price.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("price"));
		col_account.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("account"));
		col_accountEmail.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("accountEmail"));
		col_block.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("blocked"));
		
//		listM = adminPageSQL.getDatausers();
		getDataForAdmin dataforadmin = new getDataForAdmin();
		listM = dataforadmin.getDatausers();
		table_users.setItems(listM);
    }
	
	
	@FXML
    void onCloseClicked(ActionEvent event) {
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    	
    	Stage stage = new Stage();
		
		ViewLoginPage_Main loginPage = new ViewLoginPage_Main();
		loginPage.start(stage);
    }
	
	
//	@FXML
//	void serach_user() {
//		col_id.setCellValueFactory(new PropertyValueFactory<PageAdmin,Integer>("id"));
//		col_hotel.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("hotel"));
//		col_date.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("date"));
//		col_guest.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("guest"));
//		col_email.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("email"));
//		
//		col_mobile.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("mobile"));
//		col_room.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("room"));
//		col_price.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("price"));
//		col_account.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("account"));
//		col_accountEmail.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("accountEmail"));
//		
//		dataList = adminPageSQL.getDatausers();
//		table_users.setItems(dataList);
//		FilteredList<PageAdmin> filteredData = new FilteredList<>(dataList, b -> true);
//		
//		filterField.textProperty().addListener((observable,oldValue,newValue) -> {
//			filteredData.setPredicate(person ->{
//				if(newValue == null || newValue.isEmpty()) {
//					return true;
//				}
//				String lowerCaseFilter = newValue.toLowerCase();
//				
//				if(person.getHotel().toLowerCase().indexOf(lowerCaseFilter)!=-1) {
//					return true; //filter matches username
//				}else if(person.getGuest().toLowerCase().indexOf(lowerCaseFilter)!=-1) {
//					return true; //filter matches password
//				}else if(String.valueOf(person.getEmail()).indexOf(lowerCaseFilter)!=1)
//					return true; //filter matches email
//				
//					else
//						return false; //does not match
//						
//			});
//		});
//		SortedList<PageAdmin> sortedData = new SortedList<>(filteredData);
//		sortedData.comparatorProperty().bind(table_users.comparatorProperty());
//		table_users.setItems(sortedData);
//		
//	}
	
	public String[] getHotel() {
//		conn = adminPageSQL.ConnectDB();
		conn = sqlConnection.ConnectDB();
    	//String sql = "select * from hotel_details";
    	String hotelsfromsql[] = new String[2];
		try {
    		Statement stmt = conn.createStatement();
    		String sql = "select * from hotel_details";
    		ResultSet rs=stmt.executeQuery(sql);
    		int i =0;
    		while(rs.next()) {
    			hotelsfromsql[i]=rs.getString("hotelName");
    			i++;
    		}
    		
    	}catch (Exception e) {
			// TODO: handle exception
    		JOptionPane.showMessageDialog(null, e);
		}
		return hotelsfromsql;
	}
	
	public void getDate() {
		firstDate = txt_checkIn.getValue();
    	checkInDate = firstDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
    	secDate = txt_checkOut.getValue();
    	checkOutDate = secDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
    	conbinedDate = checkInDate+" To "+checkOutDate;
	}
	
	public void decodeDateFromSQL(int index) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM-dd-yyyy");
    	
    	
    	String selectedDate = col_date.getCellData(index).toString();
    	String firsts = selectedDate.substring(0,11);
    	String seconds = selectedDate.substring(15,26);
    

  	  //convert String to LocalDate
    	firstDate = LocalDate.parse(firsts, formatter);
    	secDate = LocalDate.parse(seconds, formatter);
	}
	
	


	@Override
	public void initialize(URL arg0, ResourceBundle resourceBundle) {
		// TODO Auto-generated method stub
		
		
		UpdateTable();
		String []allhotels = getHotel();
		String allrooms[] = {"1 King Room","1 Double Room","2 King Room","2 Double Room"};
		txt_hotel.getItems().addAll(allhotels);
		txt_room.getItems().addAll(allrooms);
		
		String allNameInTable[] = new String[table_users.getItems().size()];
		for(int i=0;i<table_users.getItems().size();i++) {
			allNameInTable[i]=col_account.getCellData(i).toString();
		}
		
		
	}
}
