package application;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import javax.mail.FetchProfile.Item;
import javax.swing.JOptionPane;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ControllerAdminPage implements Initializable{
	
    @FXML
    private TextField filterField;
	
    @FXML
    private TextField txt_email;

    @FXML
    private TextField txt_password;

    @FXML
    private TextField txt_type;

    @FXML
    private TextField txt_user;

    @FXML
    private TextField txt_id;

    @FXML
    private TableColumn<PageAdmin, String> col_email;

    @FXML
    private TableColumn<PageAdmin, Integer> col_id;

    @FXML
    private TableColumn<PageAdmin, String> col_password;

    @FXML
    private TableColumn<PageAdmin, String> col_type;

    @FXML
    private TableColumn<PageAdmin, String> col_username;

    @FXML
    private TableView<PageAdmin> table_users;
    
    ObservableList<PageAdmin> listM;
    ObservableList<PageAdmin> dataList ;
    
    
    int index=-1;
    Connection conn=null;
    ResultSet rs = null;
    PreparedStatement pst=null;
    
    public void Add_users() {
    	conn = adminPageSQL.ConnectDB();
    	String sql = "insert into users (username,password,email,type)values(?,?,?,?)";
    	try {
    		pst = conn.prepareStatement(sql);
    		pst.setString(1, txt_user.getText());
    		pst.setString(2, txt_password.getText());
    		pst.setString(3, txt_email.getText());
    		pst.setString(4, txt_type.getText());
    		pst.execute();
    		
    		JOptionPane.showMessageDialog(null, "Added successully");
    		UpdateTable();
    		//serach_user();
    	}catch(Exception e) {
    		JOptionPane.showMessageDialog(null, e);
    	}
    }
    
    @FXML
    void getSelected(MouseEvent event) {
    	index = table_users.getSelectionModel().getSelectedIndex();
    	if(index<=-1) {
    		return;
    	}
    	txt_id.setText(col_id.getCellData(index).toString());
    	txt_user.setText(col_username.getCellData(index).toString());
    	txt_password.setText(col_password.getCellData(index).toString());
    	txt_email.setText(col_email.getCellData(index).toString());
    	txt_type.setText(col_type.getCellData(index).toString());
    	
    	
    }
    
    public void Edit() {
    	try {
    		conn = adminPageSQL.ConnectDB();
    		String value1 = txt_id.getText();
    		String value2 = txt_user.getText();
    		String value3 = txt_password.getText();
    		String value4 = txt_email.getText();
    		String value5 = txt_type.getText();
    		
    		String sql = "update users set user_id= '"+value1+"',username= '"+value2+"',password= '"+
    				value3+"',email= '"+value4+"',type= '"+value5+"'where user_id='"+value1+"'";
    		pst = conn.prepareStatement(sql);
    		pst.execute();
    		
    		JOptionPane.showMessageDialog(null, "Updated successully");
    		UpdateTable();
    		//serach_user();
    	}catch(Exception e) {
    		JOptionPane.showMessageDialog(null, e);
    	}
    }
    
    public void Delete() {
    	conn = adminPageSQL.ConnectDB();
    	String sql = "delete from users where user_id=?";
    	try {
    		pst = conn.prepareStatement(sql);
    		pst.setString(1, txt_id.getText());
    		pst.execute();
    		JOptionPane.showMessageDialog(null, "Deleted successully");
    		UpdateTable();
    		//serach_user();
    	}catch (Exception e) {
			// TODO: handle exception
    		JOptionPane.showMessageDialog(null, e);
		}
    }
    
    public void UpdateTable() {
    	col_id.setCellValueFactory(new PropertyValueFactory<PageAdmin,Integer>("id"));
		col_username.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("username"));
		col_password.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("password"));
		col_email.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("email"));
		col_type.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("type"));
		
		listM = adminPageSQL.getDatausers();
		table_users.setItems(listM);
    }
	
	
	@FXML
    void onCloseClicked(ActionEvent event) {
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    	
    	Stage stage = new Stage();
		
		ViewLoginPage_Main loginPage = new ViewLoginPage_Main();
		loginPage.start(stage);
    }
	
	
//	@FXML
//	void serach_user() {
//		col_id.setCellValueFactory(new PropertyValueFactory<PageAdmin,Integer>("id"));
//		col_username.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("username"));
//		col_password.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("password"));
//		col_email.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("email"));
//		col_type.setCellValueFactory(new PropertyValueFactory<PageAdmin,String>("type"));
//		
//		dataList = adminPageSQL.getDatausers();
//		table_users.setItems(dataList);
//		FilteredList<PageAdmin> filteredData = new FilteredList<>(dataList, b -> true);
//		filterField.textProperty().addListener((observable,oldValue,newValue) -> {
//			filteredData.setPredicate(person ->{
//				if(newValue == null || newValue.isEmpty()) {
//					return true;
//				}
//				String lowerCaseFilter = newValue.toLowerCase();
//				
//				if(person.getUsername().toLowerCase().indexOf(lowerCaseFilter)!=-1) {
//					return true; //filter matches username
//				}else if(person.getPassword().toLowerCase().indexOf(lowerCaseFilter)!=-1) {
//					return true; //filter matches password
//				}else if(String.valueOf(person.getEmail()).indexOf(lowerCaseFilter)!=1)
//					return true; //filter matches email
//				
//					else
//						return false; //does not match
//						
//			});
//		});
//		SortedList<PageAdmin> sortedData = new SortedList<>(filteredData);
//		sortedData.comparatorProperty().bind(table_users.comparatorProperty());
//		table_users.setItems(sortedData);
//		
//	}
	


	@Override
	public void initialize(URL arg0, ResourceBundle resourceBundle) {
		// TODO Auto-generated method stub
		
		
		UpdateTable();
		//serach_user();
		
	}
}
