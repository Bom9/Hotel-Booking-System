package application;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ControllerBookingPage implements Initializable{

    @FXML
    private Label hotelSelected;
	
    @FXML
    public Label date;

    @FXML
    public Label price;

    @FXML
    public Label room;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtNum;
    
    public static String hotelselected;
    public static String mmddyy;
    public static String roomType;
    public static Integer pricing;
    public static String priceString;
    public static Integer roomNum;
    public static String roomTypeWithRoomNum;
    public static String userName;

    @FXML
    void onCloseClicked(ActionEvent event) {
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    	
    	Stage stage = new Stage();
		
		ViewResultPage resultPage = new ViewResultPage();
		resultPage.start(stage);
    }

    @FXML
    void onConfirmClicked(ActionEvent event) throws IOException {
    	Boolean nameValid,emailValid,mobileValid;
    	mobileValid = checkMobile();
    	nameValid = checkName();
    	emailValid = checkEmail();
    	int checkBooked;
    	
    		if(!nameValid)
        		JOptionPane.showMessageDialog(null, "Please enter valid name");
    		if(!mobileValid)
        		JOptionPane.showMessageDialog(null, "Please enter valid mobile number");
        	if(!emailValid)
        		JOptionPane.showMessageDialog(null, "Please enter valid email");
        	if(nameValid&&mobileValid&&emailValid) {
        		sendEmail send = new sendEmail();
        		System.out.println(userName);
        		checkBooked = checkBookSlot();
        		if(checkBooked==0) {
        			saveBookingDetails();
        			saveToPdf();
        		    send.sendConfirmedBooking(txtEmail.getText(), hotelselected, mmddyy, roomTypeWithRoomNum, priceString,txtName.getText());
        		    JOptionPane.showMessageDialog(null, "Email confirmation have sent, please check your email inbox.");
        		    ViewResultPage result = new ViewResultPage();
        		    Stage stage = new Stage();
        		    showPages showpage = new showPages();
        		    
        		    result.start(stage);
        		    showpage.closePages(event);
        		}else
        			JOptionPane.showMessageDialog(null, "Maximum one booking per user");
	        		ViewResultPage result = new ViewResultPage();
	    		    Stage stage = new Stage();
	    		    showPages showpage = new showPages();
	    		    
	    		    result.start(stage);
	    		    showpage.closePages(event);
        	}
    	
    	
    	
    }
    
    public void saveToPdf() {
    	try {
			String file_name="C:\\Users\\jianf\\Documents\\SP\\Y3 22-23 Sem 2\\ET0706 OOP\\Project\\booking_details.pdf"; 
			Document document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(file_name));
			
			document.open();
			
			String textSent = "Dear %s, \nYou have Sucessfully booked %s at %s, from %s. Total paid %s.";
	        String text = String.format(textSent, userName,roomTypeWithRoomNum,hotelSelected,mmddyy,priceString);
			
			Paragraph para=new Paragraph(text);
			
			document.add(para);
			
			
			document.close();
			System.out.println("finished");
			
		}catch(Exception e) {
			System.out.println(e);
		}
    }
    
    public void saveBookingDetails() {
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		PreparedStatement pst = con.prepareStatement("insert into confirmedbooking(hotelName,date,guestName,email,mobile,roomType,price)values(?,?,?,?,?,?,?)");
    		PreparedStatement pst2 = con.prepareStatement("UPDATE login SET booked=? WHERE name LIKE ?");
    		
    		pst.setString(1, hotelselected);
    		pst.setString(2, mmddyy);
    		pst.setString(3, txtName.getText());
    		pst.setString(4, txtEmail.getText());
    		pst.setString(5, txtNum.getText());
    		pst.setString(6, roomTypeWithRoomNum);
    		pst.setString(7, priceString);
    		pst.executeUpdate();
    		
    		pst2.setInt(1, 1);
    		pst2.setString(2, userName);
    		pst2.executeUpdate();
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
    
    public Integer checkBookSlot() {
    	int booked=1;
    	
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		
    		String sql = "Select * from login where name = '"+userName+"'";
    		ResultSet rs=stmt.executeQuery(sql);
    		
    		if(rs.next()) {
    			booked=rs.getInt("booked");
    			//System.out.println(rs.getInt("booked"));
    			 
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
    	
    	return booked;
    }
    
    public void passRoomNum(Integer roomNum) {
    	this.roomNum=roomNum;
    }
    public void passUserName(String userName) {
    	this.userName=userName;
    }
    
    public boolean checkMobile() {
    	Boolean mobileValid=false;
    	String regex =  "^\\d{8}$";
    	Pattern pattern = Pattern.compile(regex);
    	
    	Matcher matcher = pattern.matcher(txtNum.getText());
		
		if(matcher.matches()) 
			mobileValid=true;
		return mobileValid;
    }
    
    public boolean checkName() {
    	Boolean nameValid=false;
    	String regex =  "^[\\p{L} .'-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(txtName.getText());
		
		if(matcher.matches()) 
			nameValid=true;
		return nameValid;
    }
    public boolean checkEmail() {
    	Boolean emailValid=false;
    	String regex = "^[A-Za-z0-9+_.-]+@(.+)$";  
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(txtEmail.getText());
		
		if(matcher.matches()) 
			emailValid=true;
		return emailValid;
		
			
    }
    
    public void setVariables(String mmddyy, String hotelselected, Integer pricing,String roomType) {
    	this.hotelselected=hotelselected;
    	this.mmddyy=mmddyy;
    	this.roomType=roomType;
    	roomTypeWithRoomNum=String.valueOf(roomNum)+" "+roomType;
    	this.pricing=pricing;
    	pricing*=roomNum;
    	priceString="$"+pricing;
    	
    	
    }
    
    @Override
	public void initialize(URL arg0, ResourceBundle resourceBundle) {
    	System.out.println(hotelselected+" "+mmddyy+" "+roomType+" "+priceString);
		
    	date.setText(mmddyy);
    	hotelSelected.setText(hotelselected);
    	room.setText(roomTypeWithRoomNum);
    	price.setText(priceString);
    	
    
		
		
		
	}

}
