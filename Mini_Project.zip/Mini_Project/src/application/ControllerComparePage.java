package application;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import org.controlsfx.control.Rating;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ControllerComparePage implements Initializable{
	
	 @FXML
	    private VBox myBox;
	
    @FXML
    private Label facilityA;
    @FXML
    private Label facilityB;

	
	  @FXML
	    private Label priceA;

	    @FXML
	    private Label priceB;
	
	 @FXML
	 private ImageView firstImage;

	    @FXML
	    private ImageView secondImage;
	    
	
	@FXML
    private Rating ratingB;
	
	@FXML
    private Rating ratingA;
	
	 @FXML
	    private ChoiceBox<Integer> adultNum;
	 
	  @FXML
	    private ChoiceBox<Integer> roomNum;

	 @FXML
	 private ChoiceBox<String> roomType;
	
	@FXML
    private ChoiceBox<String> secondChoiceBox;

    @FXML
    private DatePicker secondDatePicker;
	
	 @FXML
	 private ChoiceBox<String> myChoiceBox;

    @FXML
    private DatePicker myDatePicker;


    @FXML
    private Label txtWelcome;
    
    //PageCompare search = new PageCompare();
	String hotels[] = new String[2];  //change the number for more hotels
	int checkInNum, checkOutNum;
	String checkInDate, checkOutDate;
	String firstHotel, secondHotel;
	String pickedHotel[] = new String[2];
	String pickedHotelTable[] = new String[2];
	boolean compareStatues = false;
	
	String roomTypeList[] = {"King Room","Double King Room"};
	String roomTypeNameInSQL[] = {"price_king_room", "price_doulbe_king_room"};
//	String roomNumList[] = {"1","2"};
	Integer[] roomNumList = {1,2};
	Integer[] adultNumList = {1,2,3,4};
    
    @FXML
    void onCloseClicked(ActionEvent event) {
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    	
    	Stage stage = new Stage();
		
		ViewMainPage mainPage = new ViewMainPage();
		mainPage.start(stage);
    }

    @FXML
    void getDate(ActionEvent event) {
    	boolean picked = checkHotelPicked();
    	if(myDatePicker.getValue() != null) {
    		if(!picked) {
        		JOptionPane.showMessageDialog(null, "Please pick hotel to compare");
        		myDatePicker.setValue(null);
        		
        	}else{
        		LocalDate firstDate = myDatePicker.getValue();
            	checkInDate = firstDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
            	
            	String checkInDayNum = firstDate.format(DateTimeFormatter.ofPattern("dd"));
            	checkInNum = Integer.parseInt(checkInDayNum);
            	//System.out.println(checkInNum);
            	checkRoomAvailable();
        	}
        	
        	
    	}
    	
    }
    @FXML
    void getSecondDate(ActionEvent event) {
    	
    	boolean picked= checkHotelPicked();
    	if(secondDatePicker.getValue() != null) {
    		if(!picked) {
        		
        		JOptionPane.showMessageDialog(null, "Please pick hotel to compare");
        		secondDatePicker.setValue(null);
        		
        		
        	}else {
        		LocalDate secondDate = secondDatePicker.getValue();
        		LocalDate firstDate = myDatePicker.getValue();
            	//System.out.println(checkIn);
        		checkOutDate = secondDate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
        		int checkOutMonthNum = Integer.parseInt(secondDate.format(DateTimeFormatter.ofPattern("MM")));
        		
        		
        		int checkInMonthNum = Integer.parseInt(firstDate.format(DateTimeFormatter.ofPattern("MM")));
        		
            	String checkOutDayNum = secondDate.format(DateTimeFormatter.ofPattern("dd"));
            	checkOutNum = Integer.parseInt(checkOutDayNum);
            	
            	if(checkInMonthNum==checkOutMonthNum) {
            		if(checkInNum>=checkOutNum) {
                		JOptionPane.showMessageDialog(null, "Please check out at later date");
                		secondDatePicker.setValue(null);
                	}
            	}
            	if(checkInMonthNum>checkOutMonthNum) {
            		JOptionPane.showMessageDialog(null, "Please check out at later date");
            		secondDatePicker.setValue(null);
            	}
            	
        	}
    	}
    	
    }
    
    void transferData(String who) {
    	txtWelcome.setText("Welcome, "+ who + "!");
    	
    }
    
    public void checkRoomAvailable() {
    	boolean statues = true;
    	
    	for(int i=0; i<hotels.length;i++) {
    		if(pickedHotel[0].equals(hotels[i]))
    			pickedHotelTable[i]="stregisbooking";
    		else if(pickedHotel[1].equals(hotels[i]))
    			pickedHotelTable[i]="parkroyalbooking";
    		
    	}
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql2 = "Select * from $tableName";
    		sql2 = sql2.replace("$tableName", pickedHotelTable[0]);
    		ResultSet rs2=stmt.executeQuery(sql2);
    		
    		while(rs2.next()) {
    			//System.out.println(rs2.getString("checkIn")); 
    			
    			if(rs2.getString("checkIn").equals(checkInDate))
    			{
    				statues=false;
    				JOptionPane.showMessageDialog(null, "Chose other available date");
    				myDatePicker.setValue(null);
    				//System.out.println("cannot choose this date");
    			}
    			
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
    	
    	if(statues==true) {
    		try {
    			Class.forName("com.mysql.cj.jdbc.Driver");
        		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
        		Statement stmt = con.createStatement();
        		String sql = "Select * from $tableName";
        		sql = sql.replace("$tableName", pickedHotelTable[1]);
        		ResultSet rs=stmt.executeQuery(sql);
        		
        		while(rs.next()) {
        			//System.out.println(rs.getString("checkIn")); 
        			
        			if(rs.getString("checkIn").equals(checkInDate))
        			{
        				statues=false;
        				JOptionPane.showMessageDialog(null, "Chose other available date");
        				myDatePicker.setValue(null);
        				//System.out.println("cannot choose this date");
        			}
        		}

    		}catch(Exception e)
    		{
    			System.out.println(e+"not found");
    		}
    	}
    	
	}
	
    

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql = "Select * from hotel_details";
    		ResultSet rs=stmt.executeQuery(sql);
    		int i=0;
    		while(rs.next()) {
    			hotels[i] = rs.getString("hotelName");
    			i++;
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
		myChoiceBox.getItems().addAll(hotels);
		myChoiceBox.setOnAction(this::getHotels);
		
		secondChoiceBox.getItems().addAll(hotels);
		secondChoiceBox.setOnAction(this::getHotels);
		
		
		roomType.getItems().addAll(roomTypeList);
		roomNum.getItems().addAll(roomNumList);
		adultNum.getItems().addAll(adultNumList);
		
	}
	
	public void getHotels(ActionEvent event) {
		String myHotel = myChoiceBox.getValue();
		pickedHotel[0] = myChoiceBox.getValue();
		pickedHotel[1] = secondChoiceBox.getValue();
		
		
	}
	
	public boolean checkHotelPicked() {
		boolean picked = false;
		
		
		if(!myChoiceBox.getSelectionModel().isEmpty())
			picked = true;
		if(!secondChoiceBox.getSelectionModel().isEmpty())
			picked = true;
		
		return picked;
	}
	
	@FXML
    void onCompareClicked(ActionEvent event) {
		boolean hotelStatues =false, dateStatues = false, roomStatues = false;
		if(!(myChoiceBox.getSelectionModel().isEmpty()||secondChoiceBox.getSelectionModel().isEmpty()))
			hotelStatues=true;
		if(myDatePicker.getValue() != null && secondDatePicker.getValue() != null)
			dateStatues = true;
		if(!(roomType.getSelectionModel().isEmpty()||roomNum.getSelectionModel().isEmpty()||adultNum.getSelectionModel().isEmpty()))
			roomStatues = true;
		
		if(hotelStatues==true && dateStatues==true && roomStatues==true)
		{
			
			displayImage();
			ratingDisplay();
			displayPrice();
			displayFacilities();
			myBox.setVisible(true);
		}else
			JOptionPane.showMessageDialog(null, "Please enter all fields");
		
    }
	
	public void ratingDisplay() {
		String firstHotel = myChoiceBox.getValue();
		String secondHotel = secondChoiceBox.getValue();
		ResultSet rs,rs2;
		rs = queryBaseOnHotel(firstHotel);
		rs2 = queryBaseOnHotel(secondHotel);
		try {
			if(rs.next())
			{
				int va = rs.getInt("rating");
				ratingA.setRating(va);
			}
			if(rs2.next())
			{
				int va = rs2.getInt("rating");
				ratingB.setRating(va);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	public void displayImage() {
		String type = roomType.getValue();
		String hotelRowName = myChoiceBox.getValue();
		if(type.equals("King Room"))
			type = "king_image";
		else
			type = "double_king_image";
		
		String firstHotel = myChoiceBox.getValue();
		String secondHotel = secondChoiceBox.getValue();
		ResultSet rs,rs2;
		rs = queryBaseOnHotel(firstHotel);
		rs2 = queryBaseOnHotel(secondHotel);
		try {
			if(rs.next())
			{
				
				InputStream is = rs.getBinaryStream(type);
	            Image image = new Image(is, 250,300,false,true);
	           
	            firstImage.setImage(image);
			}
			if(rs2.next())
			{
				InputStream is = rs2.getBinaryStream(type);
				
				is = rs2.getBinaryStream(type);
				Image image = new Image(is, 250,300,false,true);
	    		secondImage.setImage(image);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	public void displayPrice() {
		String firstHotel = myChoiceBox.getValue();
		String secondHotel = secondChoiceBox.getValue();
		String room = null;
		int numOfRoom = roomNum.getValue();
		int price;
		for(int i =0;i<2;i++) {
			if(roomType.getValue().equals(roomTypeList[i]))
			{
				room = roomTypeNameInSQL[i];
			}
		}
		
		ResultSet rs,rs2;
		rs = queryBaseOnHotel(firstHotel);
		rs2 = queryBaseOnHotel(secondHotel);
		try {
			if(rs.next())
			{
				price = rs.getInt(room)*numOfRoom;
				priceA.setText(String.valueOf(price));;
			}
			if(rs2.next())
			{
				price = rs2.getInt(room)*numOfRoom;
				priceB.setText(String.valueOf(price));;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void displayFacilities() {
	
		String firstHotel = myChoiceBox.getValue();
		String secondHotel = secondChoiceBox.getValue();
		String facilitiesA = null;
		String facilitiesB = null;
		String combineFcilitiesA="", combineFcilitiesB="";
		
		ResultSet rs,rs2;
		rs = queryBaseOnHotel(firstHotel);
		rs2 = queryBaseOnHotel(secondHotel);
		try {
			if(rs.next())
			{
				facilitiesA = rs.getString("facilities");
			}
			if(rs2.next())
			{
				facilitiesB = rs2.getString("facilities");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		List<String> decodedFacilitiesA = Arrays.asList(facilitiesA.split(","));
		List<String> decodedFacilitiesB = Arrays.asList(facilitiesB.split(","));
		for(int i=0;i<decodedFacilitiesA.size();i++) {
			combineFcilitiesA+=decodedFacilitiesA.get(i);
			combineFcilitiesA+="\n";
		}
		for(int i=0;i<decodedFacilitiesB.size();i++) {
			combineFcilitiesB+=decodedFacilitiesB.get(i);
			combineFcilitiesB+="\n";
		}
		facilityA.setText(combineFcilitiesA);
		facilityB.setText(combineFcilitiesB);
	}
	
	public ResultSet queryBaseOnHotel(String hotel) {
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		  	
    		Statement stmt = con.createStatement();
    		String sql = "select * from hotel_details where hotelName = '"+hotel+"'";
    		rs=stmt.executeQuery(sql);
    		
    		
		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
		return rs;
	}

}




