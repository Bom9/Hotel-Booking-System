package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ControllerForgotPassword {
	
	PageForgotPassword forgot = new PageForgotPassword();
	showPages jump = new showPages();
	String loginName = "";
	String email = "";
	String otp="";
	String password = "";
	String confirmedPassword = "";
	int count=0;
	
	
    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextField txtLogin;
    
    @FXML
    private TextField txtemail;
    
    @FXML
    private PasswordField txtpwd;

    @FXML
    private PasswordField txtpwdconfirm;
    
    @FXML
    private TextField txtopt;
    
    
    PageForgotPassword forgotPage = new PageForgotPassword();
    
    @FXML
    void onOTPClicked(ActionEvent event) {
    	loginName = txtLogin.getText();
    	email = txtemail.getText();
    	otp = txtopt.getText();
    	boolean sent=false;
    	if(count==0) {
    		sent = forgot.sendOTP(loginName, email, otp);
    		
    	}
    	
    	if(sent) {
    		JOptionPane.showMessageDialog(null, "OTP sent, check your email.");
    		count++;
    	}
    	else if(count!=0)
    		JOptionPane.showMessageDialog(null, "OTP only send one time, please check your email.");
    	
    	
    	
    }

    
    
    @FXML
    void onBackClicked(ActionEvent event) {
    	Stage loginStage = new Stage();
    	ViewLoginPage_Main loginPage = new ViewLoginPage_Main();
    	loginPage.start(loginStage);
    	//jump.openPages("loginPage.fxml");
    	jump.closePages(event);
    }
    

    @FXML
    void onResetClicked(ActionEvent event) {
    	loginName = txtLogin.getText();
    	email = txtemail.getText();
    	password = txtpwd.getText();
    	confirmedPassword = txtpwdconfirm.getText();
    	otp = txtopt.getText();
    	
    	forgotPage.checkResetValidity(loginName,email,otp,password,confirmedPassword,event);
    	
    	
//    	try {
//			String loginName = txtLogin.getText();
//    		Class.forName("com.mysql.cj.jdbc.Driver");
//    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
//    		Statement stmt = con.createStatement();
//    		String sql = "Select * from login where name = '"+loginName+"' ";
//    		ResultSet rs=stmt.executeQuery(sql);
//    		if(rs.next()) {
//    			System.out.println(rs.getString("email"));
//    		}
//    		else {
//    			JOptionPane.showMessageDialog(null, "Invalid login");
//    			System.out.println(rs.getString("email"));
//    		}
//    				
//    	}
//    	catch(Exception e) {System.out.println(e+"not found");}
    }

}
