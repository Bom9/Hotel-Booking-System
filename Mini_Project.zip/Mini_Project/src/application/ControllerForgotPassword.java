package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class ControllerForgotPassword {
	
	PageForgotPassword forgot = new PageForgotPassword();
	showPages jump = new showPages();
	String loginName = "";
	
    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextField txtLogin;

    @FXML
    private TextField txtotp;
    
    
    @FXML
    void onBackClicked(ActionEvent event) {
    	jump.openPages("loginPage.fxml");
    	jump.closePages(event);
    }
    
    @FXML
    void onGetOTPClicked(ActionEvent event) {
    	
    	try {
			String loginName = txtLogin.getText();
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql = "Select * from login where name = '"+loginName+"' ";
    		ResultSet rs=stmt.executeQuery(sql);
    		if(rs.next()) {
    			System.out.println(rs.getString("email"));
    		}
    		else {
    			JOptionPane.showMessageDialog(null, "Invalid login");
    			System.out.println(rs.getString("email"));
    		}
    				
    	}
    	catch(Exception e) {System.out.println(e+"not found");}
    }

    @FXML
    void onResetClicked(ActionEvent event) {
    	
    }

}
