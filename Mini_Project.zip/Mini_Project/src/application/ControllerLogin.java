package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;

public class ControllerLogin {
	
	String loginName = "";
	String password = "";
	
    @FXML
    private ImageView icon;

	@FXML
	private Hyperlink signUp;

    @FXML
    private TextField txtLogin;

    @FXML
    private PasswordField txtpwd;
    
    @FXML
    private AnchorPane anchorPane;

    
    showPages jumpToThisPage = new showPages();
    @FXML
    void onLoginClicked(ActionEvent event) {
    	loginName = txtLogin.getText();
    	password = txtpwd.getText();
    	PageLogin login = new PageLogin();
    	login.login(loginName, password,event);
    	
    }
    
    

	@FXML
    void onSignUpLinkClicked(ActionEvent event) {
		Stage registerStage = new Stage();
		ViewRegisterPage registerPage = new ViewRegisterPage();
		registerPage.start(registerStage);
//    	showPages jumpToThisPage = new showPages();
    	//jumpToThisPage.openPages("registerPage.fxml");
    	
    	jumpToThisPage.closePages(event);

    }
	
	@FXML
    void onForgotLinkClicked(ActionEvent event) {
		Stage forgotStage = new Stage();
		ViewForgotPasswordPage forgotPage = new ViewForgotPasswordPage();
		forgotPage.start(forgotStage);
		jumpToThisPage.closePages(event);
		//jumpToThisPage.openPages("forgotPasswordPage.fxml");
		
		
    }

}
