package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;

public class ControllerMainPage {

    @FXML
    void onCompareClicked(ActionEvent event) {
    	ViewComparePage comparePage = new ViewComparePage();
    	Stage stage = new Stage();
    	comparePage.start(stage);
    	
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    }

    @FXML
    void onSeachClicked(ActionEvent event) {
    	ViewSearchPage searchPage = new ViewSearchPage();
    	Stage stage = new Stage();
    	searchPage.start(stage);
    	
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    }
    
    @FXML
    void onLogOutClicked(ActionEvent event) {
    	ViewLoginPage_Main loginPage = new ViewLoginPage_Main();
    	Stage stage = new Stage();
    	loginPage.start(stage);
    	
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    }

}
