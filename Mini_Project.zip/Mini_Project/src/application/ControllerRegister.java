package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ControllerRegister {

	String loginName = "";
	String password = "";
	String email = "";
	Stage stage;
	ActionEvent event;

	@FXML
    private TextField txtLogin;

    @FXML
    private PasswordField txtpwd;
    
    @FXML
    private PasswordField txtemail;
    
    @FXML
    void onBackClicked(ActionEvent event) {
    	this.event = event;
    	showPages jumpToThisPage = new showPages();
    	jumpToThisPage.openPages("loginPage.fxml");
    	jumpToThisPage.closePages(event);
    }

    @FXML
    void onSignUpClicked(ActionEvent event) {
    	loginName = txtLogin.getText();
    	password = txtpwd.getText();
    	email = txtemail.getText();
    	PageRegister register = new PageRegister();
    	register.register(loginName, password, email,event);
    	
    }

}
