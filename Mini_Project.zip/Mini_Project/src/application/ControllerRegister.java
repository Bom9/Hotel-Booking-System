package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ControllerRegister {

	String loginName = "";
	String password = "";
	String confirmedPassword ="";
	String email = "";
	Stage stage;
	ActionEvent event;

	@FXML
    private TextField txtLogin;

    @FXML
    private PasswordField txtpwd;
    
    @FXML
    private TextField txtemail;
    
    @FXML
    private PasswordField txtpwdconfirm;
    
    @FXML
    void onBackClicked(ActionEvent event) {
    	this.event = event;
    	showPages jumpToThisPage = new showPages();
    	//jumpToThisPage.openPages("loginPage.fxml");
    	jumpToThisPage.closePages(event);
    	
    	Stage loginStage = new Stage();
    	ViewLoginPage_Main loginPage = new ViewLoginPage_Main();
    	loginPage.start(loginStage);
    }

    @FXML
    void onSignUpClicked(ActionEvent event) {
    	loginName = txtLogin.getText();
    	password = txtpwd.getText();
    	confirmedPassword = txtpwdconfirm.getText();
    	email = txtemail.getText();
    	PageRegister register = new PageRegister();
    	register.register(loginName, password, confirmedPassword, email,event);
    	
    }

}
