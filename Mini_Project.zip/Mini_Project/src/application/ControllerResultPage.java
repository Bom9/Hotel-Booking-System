package application;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import javax.mail.FetchProfile.Item;
import javax.swing.JOptionPane;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class ControllerResultPage implements Initializable{
	

    @FXML
    private TableColumn<PageResult,Button> buttonCol;
    
    @FXML
    private TableColumn<PageResult,Button> buttonCol2;

    @FXML
    private TableColumn<PageResult, String> addressCol;
	
    @FXML
    private TableColumn<PageResult, InputStream> imageCol;
    
    @FXML
    private TableColumn<PageResult, Integer> priceCol;
    
    
    @FXML
    private TableColumn<PageResult, InputStream> imageCol2;
    
    @FXML
    private TableColumn<PageResult, Integer> priceCol2;

    @FXML
    private TableColumn<PageResult, Integer> ratingCol;

	@FXML
    private Label checkInDate;

    @FXML
    private Label checkOutDate;

    @FXML
    private TableColumn<PageResult, String> hotelCol;

    @FXML
    private Label hotelSearched;

    @FXML
    private TableView<PageResult> listHotel;
    
    public static Button []button = new Button[4];
    public static Integer data;
    public static String hotelBooked;
	
	ObservableList<PageResult> listM;
	int index =-1;
	Connection conn =null;
	ResultSet rs = null;
	PreparedStatement pst = null;

	@FXML
    void onCloseClicked(ActionEvent event) {
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    	
    	Stage stage = new Stage();
		
		ViewSearchPage searchPage = new ViewSearchPage();
		searchPage.start(stage);
    }
	
	public static String checkIn;
	public static String checkOut;
	public static String hotelName;
	public void setAll(String checkIn, String checkOut, String hotelName) {
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.hotelName = hotelName;
	}
    
  public void handleButtonAction(ActionEvent event) {
	  
	  PageResult item;
	  TableColumn<PageResult, ?> col;
	    
	  if(event.getSource() == button[0]) {
		    item = listHotel.getItems().get(0); //get row
		    col = listHotel.getColumns().get(4); //get column
		    data = (Integer) col.getCellObservableValue(item).getValue(); // this gives the value in the selected cell:
		    
		    col = listHotel.getColumns().get(0);
		    hotelBooked = (String) col.getCellObservableValue(item).getValue();
		   
		    booking(event);
	  }
	  if(event.getSource() == button[1]) {
		  item = listHotel.getItems().get(0); //get row
		    col = listHotel.getColumns().get(7); //get column
		    data = (Integer) col.getCellObservableValue(item).getValue(); // this gives the value in the selected cell:
		    
		    col = listHotel.getColumns().get(0);
		    hotelBooked = (String) col.getCellObservableValue(item).getValue();
		   
		    booking(event);
	  }
	  if(event.getSource() == button[2]) {
		  	item = listHotel.getItems().get(1); //get row
		    col = listHotel.getColumns().get(4); //get column
		    data = (Integer) col.getCellObservableValue(item).getValue(); // this gives the value in the selected cell:
		    
		    col = listHotel.getColumns().get(0);
		    hotelBooked = (String) col.getCellObservableValue(item).getValue();
		   
		    booking(event);
	  }
	  if(event.getSource() == button[3]) {
		  	item = listHotel.getItems().get(1); //get row
		    col = listHotel.getColumns().get(7); //get column
		    data = (Integer) col.getCellObservableValue(item).getValue(); // this gives the value in the selected cell:
		    
		    col = listHotel.getColumns().get(0);
		    hotelBooked = (String) col.getCellObservableValue(item).getValue();
		   
		    booking(event);
	  }
  }
  
  public void booking(ActionEvent event) {
	  System.out.println("hotel: "+hotelBooked+" price: "+data);
	  String roomType;
	  if(data==192||data==182)
		  roomType="King Room";
	  else
		  roomType="Double King Room";
	  
	  String date = checkIn+" To "+checkOut;
	  
	  ControllerBookingPage controllerBooking = new ControllerBookingPage();
	  controllerBooking.setVariables(checkIn, checkOut, hotelBooked, data, roomType);
	  
	  Stage stage = new Stage();
	  ViewBookingPage booking = new ViewBookingPage();
	  showPages showpage = new showPages();
	  booking.start(stage);
	  showpage.closePages(event);
	  
	  
  }
   
    
	@Override
	public void initialize(URL arg0, ResourceBundle resourceBundle) {
		
		// TODO Auto-generated method stub
		imageCol.setCellValueFactory(new PropertyValueFactory<PageResult, InputStream>("image"));
		hotelCol.setCellValueFactory(new PropertyValueFactory<PageResult, String>("hotel"));
		ratingCol.setCellValueFactory(new PropertyValueFactory<PageResult, Integer>("rating"));
		addressCol.setCellValueFactory(new PropertyValueFactory<PageResult, String>("address"));
		priceCol.setCellValueFactory(new PropertyValueFactory<PageResult, Integer>("price"));
		buttonCol.setCellValueFactory(new PropertyValueFactory<PageResult, Button>("button"));
		imageCol2.setCellValueFactory(new PropertyValueFactory<PageResult, InputStream>("image2"));
		priceCol2.setCellValueFactory(new PropertyValueFactory<PageResult, Integer>("price2"));
		buttonCol2.setCellValueFactory(new PropertyValueFactory<PageResult, Button>("button2"));
		
		checkInDate.setText(checkIn);
		checkOutDate.setText(checkOut);
		hotelSearched.setText(hotelName);
		
		
		for(int i =0;i<button.length;i++) {
			button[i]=new Button();
			button[i].setOnAction(this::handleButtonAction);
		}
		
		
		
		listM = resultPageSQL.getDatausers();
		listHotel.setItems(listM);
		
	}

	
	
	

}
