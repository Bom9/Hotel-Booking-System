package application;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class ControllerResultPage implements Initializable{


    @FXML
    private TableColumn<PageResult, String> addressCol;
	
    @FXML
    private TableColumn<PageResult, InputStream> imageCol;
    
    @FXML
    private TableColumn<PageResult, Integer> priceCol;

    @FXML
    private TableColumn<PageResult, Integer> ratingCol;

	@FXML
    private Label checkInDate;

    @FXML
    private Label checkOutDate;

    @FXML
    private TableColumn<PageResult, String> hotelCol;

    @FXML
    private Label hotelSearched;

    @FXML
    private TableView<PageResult> listHotel;

	
	ObservableList<PageResult> listM;
	int index =-1;
	Connection conn =null;
	ResultSet rs = null;
	PreparedStatement pst = null;

	@FXML
    void onCloseClicked(ActionEvent event) {
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    	
    	Stage stage = new Stage();
		
		ViewSearchPage searchPage = new ViewSearchPage();
		searchPage.start(stage);
    }
	
	public static String checkIn;
	public static String checkOut;
	public static String hotelName;
	public void setAll(String checkIn, String checkOut, String hotelName) {
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.hotelName = hotelName;
	}
    
  
   
    
	@Override
	public void initialize(URL arg0, ResourceBundle resourceBundle) {
		// TODO Auto-generated method stub
		imageCol.setCellValueFactory(new PropertyValueFactory<PageResult, InputStream>("image"));
		hotelCol.setCellValueFactory(new PropertyValueFactory<PageResult, String>("hotel"));
		ratingCol.setCellValueFactory(new PropertyValueFactory<PageResult, Integer>("rating"));
		addressCol.setCellValueFactory(new PropertyValueFactory<PageResult, String>("address"));
		priceCol.setCellValueFactory(new PropertyValueFactory<PageResult, Integer>("price"));
		
		checkInDate.setText(checkIn);
		checkOutDate.setText(checkOut);
		hotelSearched.setText(hotelName);
		
		listM = resultPageSQL.getDatausers();
		listHotel.setItems(listM);
		
	}

	
	
	

}
