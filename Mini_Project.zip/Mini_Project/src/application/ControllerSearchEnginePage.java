package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ControllerSearchEnginePage {

    @FXML
    private Label txtWelcome;

    void transferData(String who) {
    	txtWelcome.setText("Welcome, "+ who + "!");
    }
}
