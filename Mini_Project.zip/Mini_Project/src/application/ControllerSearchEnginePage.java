package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import org.controlsfx.control.Rating;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ControllerSearchEnginePage implements Initializable{
	
	PageSearchEngine search = new PageSearchEngine();
	String hotels[] = new String[2];  //change the number for more hotels
	int checkInNum, checkOutNum;
	String checkInDate, checkOutDate;
	String firstHotel, secondHotel;
	String pickedHotel[] = new String[2];
	String pickedHotelTable[] = new String[2];
	boolean compareStatues = false;
	
	String roomTypeList[] = {"King Room","Double King Room"};
//	String roomNumList[] = {"1","2"};
Integer[] roomNumList = {1,2};
	Integer[] adultNumList = {1,2,3,4};
	
	
	 @FXML
	 private ImageView firstImage;

	    @FXML
	    private ImageView secondImage;
	    
	
	@FXML
    private Rating ratingB;
	
	@FXML
    private Rating ratingA;
	
	 @FXML
	    private ChoiceBox<Integer> adultNum;
	 
	  @FXML
	    private ChoiceBox<Integer> roomNum;

	 @FXML
	 private ChoiceBox<String> roomType;
	
	@FXML
    private ChoiceBox<String> secondChoiceBox;

    @FXML
    private DatePicker secondDatePicker;
	
	 @FXML
	 private ChoiceBox<String> myChoiceBox;

    @FXML
    private DatePicker myDatePicker;


    @FXML
    private Label txtWelcome;
    

    @FXML
    void getDate(ActionEvent event) {
    	boolean picked = checkHotelPicked();
    	if(myDatePicker.getValue() != null) {
    		if(!picked) {
        		JOptionPane.showMessageDialog(null, "Please pick hotel to compare");
        		myDatePicker.setValue(null);
        		
        	}else{
        		LocalDate firstDate = myDatePicker.getValue();
            	checkInDate = firstDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
            	
            	String abc = firstDate.format(DateTimeFormatter.ofPattern("dd"));
            	checkInNum = Integer.parseInt(abc);
            	//System.out.println(checkInNum);
            	checkRoomAvailable();
        	}
        	
        	
    	}
    	
    	//myLabel.setText(checkInDate);
    	//search.compare(checkInDate);
    }
    @FXML
    void getSecondDate(ActionEvent event) {
    	
    	boolean picked= checkHotelPicked();
    	if(secondDatePicker.getValue() != null) {
    		if(!picked) {
        		
        		JOptionPane.showMessageDialog(null, "Please pick hotel to compare");
        		secondDatePicker.setValue(null);
        		
        		
        	}else {
        		LocalDate secondDate = secondDatePicker.getValue();
            	//System.out.println(checkIn);
            	checkOutDate = secondDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
            	String abc = secondDate.format(DateTimeFormatter.ofPattern("dd"));
            	checkOutNum = Integer.parseInt(abc);
        		if(checkInNum>=checkOutNum) {
            		JOptionPane.showMessageDialog(null, "Please check out at later date");
            		secondDatePicker.setValue(null);
            	}
        	}
    	}
    	
    }
    
    void transferData(String who) {
    	txtWelcome.setText("Welcome, "+ who + "!");
    	
    }
    
    public void checkRoomAvailable() {
    	boolean statues = true;
    	
    	for(int i=0; i<hotels.length;i++) {
    		if(pickedHotel[0].equals(hotels[i]))
    			pickedHotelTable[i]="stregisbooking";
    		else if(pickedHotel[1].equals(hotels[i]))
    			pickedHotelTable[i]="parkroyalbooking";
    		
    	}
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql2 = "Select * from $tableName";
    		sql2 = sql2.replace("$tableName", pickedHotelTable[0]);
    		ResultSet rs2=stmt.executeQuery(sql2);
    		
    		while(rs2.next()) {
    			//System.out.println(rs2.getString("checkIn")); 
    			
    			if(rs2.getString("checkIn").equals(checkInDate))
    			{
    				statues=false;
    				JOptionPane.showMessageDialog(null, "Chose other available date");
    				myDatePicker.setValue(null);
    				//System.out.println("cannot choose this date");
    			}
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
    	
    	if(statues==true) {
    		try {
    			Class.forName("com.mysql.cj.jdbc.Driver");
        		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
        		Statement stmt = con.createStatement();
        		String sql = "Select * from $tableName";
        		sql = sql.replace("$tableName", pickedHotelTable[1]);
        		ResultSet rs=stmt.executeQuery(sql);
        		
        		while(rs.next()) {
        			//System.out.println(rs.getString("checkIn")); 
        			
        			if(rs.getString("checkIn").equals(checkInDate))
        			{
        				statues=false;
        				JOptionPane.showMessageDialog(null, "Chose other available date");
        				myDatePicker.setValue(null);
        				//System.out.println("cannot choose this date");
        			}
        		}

    		}catch(Exception e)
    		{
    			System.out.println(e+"not found");
    		}
    	}
    	
	}
	
    

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql = "Select * from hotel_details";
    		ResultSet rs=stmt.executeQuery(sql);
    		int i=0;
    		while(rs.next()) {
    			hotels[i] = rs.getString("hotelName");
    			i++;
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
		myChoiceBox.getItems().addAll(hotels);
		myChoiceBox.setOnAction(this::getHotels);
		
		secondChoiceBox.getItems().addAll(hotels);
		secondChoiceBox.setOnAction(this::getHotels);
		
		
		roomType.getItems().addAll(roomTypeList);
		roomNum.getItems().addAll(roomNumList);
		adultNum.getItems().addAll(adultNumList);
		
	}
	
	public void getHotels(ActionEvent event) {
		String myHotel = myChoiceBox.getValue();
		pickedHotel[0] = myChoiceBox.getValue();
		pickedHotel[1] = secondChoiceBox.getValue();
		
		
	}
	
	public boolean checkHotelPicked() {
		boolean picked = false;
		
		
		if(!myChoiceBox.getSelectionModel().isEmpty())
			picked = true;
		if(!secondChoiceBox.getSelectionModel().isEmpty())
			picked = true;
		
		return picked;
	}
	
	@FXML
    void onCompareClicked(ActionEvent event) {
		boolean hotelStatues =false, dateStatues = false, roomStatues = false;
		if(!(myChoiceBox.getSelectionModel().isEmpty()&&secondChoiceBox.getSelectionModel().isEmpty()))
			hotelStatues=true;
		if(myDatePicker.getValue() != null && secondDatePicker.getValue() != null)
			dateStatues = true;
		if(!(roomType.getSelectionModel().isEmpty()&&roomNum.getSelectionModel().isEmpty()&&adultNum.getSelectionModel().isEmpty()))
			roomStatues = true;
		
		if(hotelStatues==true && dateStatues==true && roomStatues==true)
			System.out.println("all clear");
		
		
//		try {
//			Class.forName("com.mysql.cj.jdbc.Driver");
//    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
//    		  	
//    		Statement stmt = con.createStatement();
//    		String sql = "select * from hotel_details";
//    		ResultSet rs=stmt.executeQuery(sql);
//    		rs.next();
//    		InputStream is = rs.getBinaryStream("king_image");
//            Image image = new Image(is, 250,300,false,true);
//            firstKingImage.setImage(image);
//            rs.next();
//    		is = rs.getBinaryStream("king_image");
//    		image = new Image(is, 250,300,false,true);
//    		secondKingImage.setImage(image);
//    		
//		}catch(Exception e)
//		{
//			System.out.println(e+"not found");
//		}
		displayImage();
			
		
		ratingDisplay();
		
    }
	
	public void ratingDisplay() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql2 = "Select * from hotel_details where hotelName = '"+myChoiceBox.getValue()+"'";
    		ResultSet rs2=stmt.executeQuery(sql2);
    		
    		if(rs2.next()) {
    			int va = rs2.getInt("rating");
    			ratingA.setRating(va);
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql2 = "Select * from hotel_details where hotelName = '"+secondChoiceBox.getValue()+"'";
    		ResultSet rs2=stmt.executeQuery(sql2);
    		
    		if(rs2.next()) {
    			int va = rs2.getInt("rating");
    			ratingB.setRating(va);
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
	}
	
	public void displayImage() {
		String type = roomType.getValue();
		String hotelRowName = myChoiceBox.getValue();
		if(type.equals("King Room"))
			type = "king_image";
		else
			type = "double_king_image";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		  	
    		Statement stmt = con.createStatement();
    		String sql = "select * from hotel_details";
    		//sql = sql.replace("$name", hotelRowName);
    		ResultSet rs=stmt.executeQuery(sql);
    		rs.next();
    		InputStream is = rs.getBinaryStream(type);
            Image image = new Image(is, 250,300,false,true);
            firstImage.setImage(image);
            rs.next();
    		is = rs.getBinaryStream(type);
    		image = new Image(is, 250,300,false,true);
    		secondImage.setImage(image);
    		
		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
		
	}

}




