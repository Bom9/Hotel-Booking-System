package application;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import org.controlsfx.control.Rating;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ControllerSearchPage implements Initializable{
	
    @FXML
    private ChoiceBox<Integer> adultNum;

    @FXML
    private ChoiceBox<String> myChoiceBox;

    @FXML
    private DatePicker myDatePicker;


    @FXML
    private ChoiceBox<Integer> roomNum;


	@FXML
    private DatePicker secondDatePicker;

    
    //PageCompare search = new PageCompare();
	String hotels[] = new String[2];  //change the number for more hotels
	int checkInNum, checkOutNum;
	String checkInDate, checkOutDate;
	String firstHotel, secondHotel;
	String pickedHotel[] = new String[2];
	String pickedHotelTable[] = new String[2];
	boolean compareStatues = false;
	
	String roomTypeList[] = {"King Room","Double King Room"};
	String roomTypeNameInSQL[] = {"price_king_room", "price_doulbe_king_room"};
//	String roomNumList[] = {"1","2"};
	Integer[] roomNumList = {1,2};
	Integer[] adultNumList = {1,2,3,4};
    
    @FXML
    void onCloseClicked(ActionEvent event) {
    	showPages showPage = new showPages();
    	showPage.closePages(event);
    	
    	Stage stage = new Stage();
		
		ViewMainPage mainPage = new ViewMainPage();
		mainPage.start(stage);
    }

    @FXML
    void getDate(ActionEvent event) {
    	boolean picked = checkHotelPicked();
    	if(myDatePicker.getValue() != null) {
    		if(!picked) {
        		JOptionPane.showMessageDialog(null, "Please pick hotel to compare");
        		myDatePicker.setValue(null);
        		
        	}else{
        		LocalDate firstDate = myDatePicker.getValue();
            	checkInDate = firstDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
            	
            	String abc = firstDate.format(DateTimeFormatter.ofPattern("dd"));
            	checkInNum = Integer.parseInt(abc);
            	//System.out.println(checkInNum);
            	checkRoomAvailable();
        	}
        	
        	
    	}
    	
    }
    @FXML
    void getSecondDate(ActionEvent event) {
    	
    	boolean picked= checkHotelPicked();
    	if(secondDatePicker.getValue() != null) {
    		if(!picked) {
        		
        		JOptionPane.showMessageDialog(null, "Please pick hotel to compare");
        		secondDatePicker.setValue(null);
        		
        		
        	}else {
        		LocalDate secondDate = secondDatePicker.getValue();
        		LocalDate firstDate = myDatePicker.getValue();
            	//System.out.println(checkIn);
        		checkOutDate = secondDate.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy"));
        		int checkOutMonthNum = Integer.parseInt(secondDate.format(DateTimeFormatter.ofPattern("MM")));
        		
        		
        		int checkInMonthNum = Integer.parseInt(firstDate.format(DateTimeFormatter.ofPattern("MM")));
        		
            	String checkOutDayNum = secondDate.format(DateTimeFormatter.ofPattern("dd"));
            	checkOutNum = Integer.parseInt(checkOutDayNum);
            	
            	if(checkInMonthNum==checkOutMonthNum) {
            		if(checkInNum>=checkOutNum) {
                		JOptionPane.showMessageDialog(null, "Please check out at later date");
                		secondDatePicker.setValue(null);
                	}
            	}
            	if(checkInMonthNum>checkOutMonthNum) {
            		JOptionPane.showMessageDialog(null, "Please check out at later date");
            		secondDatePicker.setValue(null);
            	}
        	}
    	}
    	
    }
    
    
    public void checkRoomAvailable() {
    	boolean statues = true;
    	
    	for(int i=0; i<hotels.length;i++) {
    		if(pickedHotel[0].equals(hotels[i])) {
    			pickedHotelTable[0]="stregisbooking";
    			break;
    		}
    		else
    			pickedHotelTable[0]="parkroyalbooking";
    		
    	}
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql2 = "Select * from $tableName";
    		sql2 = sql2.replace("$tableName", pickedHotelTable[0]);
    		ResultSet rs2=stmt.executeQuery(sql2);
    		
    		while(rs2.next()) {
    			//System.out.println(rs2.getString("checkIn")); 
    			
    			if(rs2.getString("checkIn").equals(checkInDate))
    			{
    				statues=false;
    				JOptionPane.showMessageDialog(null, "Chose other available date");
    				myDatePicker.setValue(null);
    				//System.out.println("cannot choose this date");
    			}
    		}

		}catch(Exception e)
		{
			System.out.println(pickedHotelTable[0]);
			System.out.println(e+"not found");
		}
    	
	}
	
    

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql = "Select * from hotel_details";
    		ResultSet rs=stmt.executeQuery(sql);
    		int i=0;
    		while(rs.next()) {
    			hotels[i] = rs.getString("hotelName");
    			i++;
    		}

		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
		myChoiceBox.getItems().addAll(hotels);
		myChoiceBox.setOnAction(this::getHotels);
		
		
		roomNum.getItems().addAll(roomNumList);
		adultNum.getItems().addAll(adultNumList);
		
	}
	
	public void getHotels(ActionEvent event) {
		String myHotel = myChoiceBox.getValue();
		pickedHotel[0] = myChoiceBox.getValue();
		//pickedHotel[1] = secondChoiceBox.getValue();
		
	}
	
	public boolean checkHotelPicked() {
		boolean picked = false;
		
		if(!myChoiceBox.getSelectionModel().isEmpty())
			picked = true;
		
		return picked;
	}
	
	@FXML
    void onCompareClicked(ActionEvent event) {
		boolean hotelStatues =false, dateStatues = false, roomStatues = false;
		if(!(myChoiceBox.getSelectionModel().isEmpty()))
			hotelStatues=true;
		if(myDatePicker.getValue() != null && secondDatePicker.getValue() != null)
			dateStatues = true;
		if(!(roomNum.getSelectionModel().isEmpty()||adultNum.getSelectionModel().isEmpty()))
			roomStatues = true;
		
		if(hotelStatues==true && dateStatues==true && roomStatues==true)
		{
			ViewResultPage resultPage = new ViewResultPage();
			Stage stage = new Stage();
			showPages showpage = new showPages();
			
			ControllerResultPage result = new ControllerResultPage();
			result.setAll(checkInDate, checkOutDate, myChoiceBox.getValue());
			
			resultPageSQL sql = new resultPageSQL();
			sql.getHotel(myChoiceBox.getValue());
			
			ControllerBookingPage booking = new ControllerBookingPage();
			booking.passRoomNum(roomNum.getSelectionModel().getSelectedItem());
			
			showpage.closePages(event);
			resultPage.start(stage);
		}else
			JOptionPane.showMessageDialog(null, "Please enter all fields");
		
    }
	
	
	public ResultSet queryBaseOnHotel(String hotel) {
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		  	
    		Statement stmt = con.createStatement();
    		String sql = "select * from hotel_details where hotelName = '"+hotel+"'";
    		rs=stmt.executeQuery(sql);
    		
    		
		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
		return rs;
	}

}




