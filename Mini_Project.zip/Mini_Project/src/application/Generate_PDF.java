package application;

import java.io.FileOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class Generate_PDF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			String file_name="C:\\Users\\jianf\\Documents\\SP\\Y3 22-23 Sem 2\\ET0706 OOP\\Project\\booking_details.pdf"; 
			Document document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(file_name));
			
			document.open();
			
			Paragraph para=new Paragraph("This ");
			
			document.add(para);
			
			
			document.close();
			System.out.println("finished");
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		
	}

}
