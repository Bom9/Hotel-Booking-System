package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PageCompare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	
	public void start(String name) {
		try {
			FXMLLoader loader = new FXMLLoader
					(getClass().getResource("comparePage.fxml"));
			
			AnchorPane root = (AnchorPane)loader.load(); //these two statments equavilent to the first statment
			Stage search = new Stage(); 
			Scene scene2 = new Scene(root,400,400);
			search.initModality(Modality.APPLICATION_MODAL);
			search.setScene(scene2);
			
			ControllerComparePage controller = loader.getController();
			controller.transferData(name);
			search.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	public void compare(String checkIn) {
		System.out.println(checkIn);
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		PreparedStatement pst = con.prepareStatement("insert into parkroyalbooking(checkIn)values(?)");
    		int status=0;
    		
    		pst.setString(1, "Jan-15-2023");
    		pst.executeUpdate();
			
			
		}catch(Exception e)
		{
			System.out.println(e+"not found");
		}
	}

}
