package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.stage.Stage;

public class PageForgotPassword {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	}
	String loginName = "";
	String email = "";
	String otp="";
	String password = "";
	String confirmedPassword = "";
	Boolean nameEmailValid = false;
	Boolean passwordValid = false;
	boolean proceedAfterOTP=false;
	sendEmail sendotp = new sendEmail();
	ActionEvent event;
	public void checkResetValidity(String loginName, String email, String password, String confirmedPassword, ActionEvent event) {
		this.loginName = loginName;
		this.email = email;
		this.password = password;
		this.confirmedPassword = confirmedPassword;
		this.event = event;
		
		checkNameEmail();
		checkPassword();
		if(nameEmailValid&&passwordValid&&proceedAfterOTP) {
			resetPassword();
		}else {
			
			JOptionPane.showMessageDialog(null, "Please double confirm your particulars");
		}
	}
	
	public void sendOTP(String loginName, String email, String otp) {
		this.loginName = loginName;
		this.email = email;
		this.otp = otp;
		
		checkNameEmail();
		if(nameEmailValid) {
			sendotp.sendOTP(email);
		}
		else
			JOptionPane.showMessageDialog(null, "Please use registered username and email");
			
	}
	
	public void checkNameEmail() {
		ResultSet rs = querySQL();
		try {
			if(loginName.equals(rs.getString("name"))&&email.equals(rs.getString("email"))){
				nameEmailValid=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void checkPassword() {
		if(password.equals(confirmedPassword)) {
			passwordValid=true;
			if(otp.equals(sendotp.otp))
				proceedAfterOTP=true;
			
		}
			
	}
	
	public void resetPassword() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		PreparedStatement pst = con.prepareStatement("UPDATE login SET password=? WHERE name LIKE ?");
    	
    		pst.setString(1, confirmedPassword);
    		pst.setString(2, loginName);
    		pst.executeUpdate();
    		
    		JOptionPane.showMessageDialog(null, "Successfully reset your password");
    		
    		showPages jumpToThisPage = new showPages();
			
	    	jumpToThisPage.closePages(event);
    		Stage loginStage = new Stage();
	    	ViewLoginPage_Main loginPage = new ViewLoginPage_Main();
	    	loginPage.start(loginStage);
    		
    		
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e+"not found");
		}
	}
	
	public ResultSet querySQL() {
		ResultSet rs = null;
		
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql = "Select * from login where name = '"+loginName+"' ";
    		rs=stmt.executeQuery(sql);
    		if(rs.next()) {
    			return rs;
    		}
    		else {
    			JOptionPane.showMessageDialog(null, "User name not exist");
    			//System.out.println(rs.getString("email"));
    		}
    				
    	}
    	catch(Exception e) {System.out.println(e+"not found");}
    	return rs;
	}
	

}
