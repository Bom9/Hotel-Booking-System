package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;

public class PageForgotPassword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String loginName = "abc";
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql = "Select * from login where name = '"+loginName+"' ";
    		ResultSet rs=stmt.executeQuery(sql);
    		if(rs.next()) {
    			System.out.println(rs.getString("email"));
    		}
    		else {
    			JOptionPane.showMessageDialog(null, "Invalid login");
    		}
    				
    	}
    	catch(Exception e) {System.out.println(e+"not found");}
	}
	

}
