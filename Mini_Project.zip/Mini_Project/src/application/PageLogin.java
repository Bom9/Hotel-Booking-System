package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;

public class PageLogin {
	String loginName = "";
	String password = "";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void login(String loginName, String password, ActionEvent event) {
		this.loginName = loginName;
		this.password = password;
		boolean admin;
		try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		Statement stmt = con.createStatement();
    		String sql = "Select * from login where name= '"+loginName+"' and password= '"+password+"'";
    		ResultSet rs=stmt.executeQuery(sql);
    		if(rs.next()&&loginName!=""&&password!="") {
    			JOptionPane.showMessageDialog(null, "Successful login");
    			
    			showPages jumpToThisPage = new showPages();
    	    	jumpToThisPage.closePages(event);

    			Stage stage = new Stage();
    			admin = checkAdmin();
    			if(admin) {
    				ViewAdminPage adminPage = new ViewAdminPage();
    				adminPage.start(stage);
    			}else {
	    			ViewMainPage mainPage = new ViewMainPage();
	    			mainPage.start(stage);
    			}
    			
    			
    		}
    		else {
    			JOptionPane.showMessageDialog(null, "Either username of password is incorrect");
    		}
    				
    	}
    	catch(Exception e) {System.out.println(e+"not found");}
	}
	
	 public boolean checkAdmin() {
	    	boolean admin=false;
	    	try {
	    		Class.forName("com.mysql.cj.jdbc.Driver");
	    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
	    		Statement stmt = con.createStatement();
	    		String sql = "Select * from login where name = '"+loginName+"'";
	    		ResultSet rs=stmt.executeQuery(sql);
	    		if(rs.next()) {
	    			if(rs.getString("name").equals("admin"))
	    				admin=true;
	    		}
	    		
	    	}catch(Exception e) {
	    		System.out.println(e);
	    	}
			return admin;
	    }

}
