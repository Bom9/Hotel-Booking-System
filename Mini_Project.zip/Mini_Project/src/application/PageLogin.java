package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;

public class PageLogin {
	String loginName = "";
	String password = "";

	
	public PageLogin(String loginName, String password) {
		this.loginName=loginName;
		this.password=password;
		// TODO Auto-generated constructor stub
	}
	
	public void login( ActionEvent event) {
		
		boolean admin;
		try {

			Connection con = sqlConnection.ConnectDB();
    		Statement stmt = con.createStatement();
    		String sql = "Select * from login where name= '"+loginName+"' and password= '"+password+"'";
    		ResultSet rs=stmt.executeQuery(sql);
    		if(rs.next()&&loginName!=""&&password!="") {
    			JOptionPane.showMessageDialog(null, "Successful login");
    			
    			showPages jumpToThisPage = new showPages();
    	    	jumpToThisPage.closePages(event);

    			Stage stage = new Stage();
    			admin = checkAdmin();
    			if(admin) {
    				ViewAdminPage adminPage = new ViewAdminPage();
    				adminPage.start(stage);
    			}else {
	    			ViewMainPage mainPage = new ViewMainPage();
	    			mainPage.start(stage);
    			}
    			
    			
    		}
    		else {
    			JOptionPane.showMessageDialog(null, "Either username of password is incorrect");
    		}
    				
    	}
    	catch(Exception e) {System.out.println(e+"not found");}
	}
	
	 public boolean checkAdmin() {
	    	boolean admin=false;
	    	try {
	    		
	    		Connection con = sqlConnection.ConnectDB();
	    		Statement stmt = con.createStatement();
	    		String sql = "Select * from login where name = '"+loginName+"'";
	    		ResultSet rs=stmt.executeQuery(sql);
	    		if(rs.next()) {
	    			if(rs.getString("name").equals("admin"))
	    				admin=true;
	    		}
	    		
	    	}catch(Exception e) {
	    		System.out.println(e);
	    	}
			return admin;
	    }

}
