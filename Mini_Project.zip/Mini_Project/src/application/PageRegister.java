package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class PageRegister {
	
	String loginName = "";
	String password = "";
	String confirmedPassword = "";
	String email = "";
	
	
	public void register(String loginName, String password, String confirmedPassword, String email, ActionEvent event) {
		this.loginName = loginName;
		this.password = password;
		this.email = email;
		this.confirmedPassword = confirmedPassword;
		
		try {
    		Connection con = sqlConnection.ConnectDB();
    		PreparedStatement pst = con.prepareStatement("insert into login(name,password,email)values(?,?,?)");
    		int status=0;

    		boolean saveToSQL = true;
    		String query = "SELECT * FROM login WHERE name = '"+loginName+"'";
			ResultSet existing_user = pst.executeQuery(query);
			
			String regex = "^[A-Za-z0-9+_.-]+@(.+)$";  
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(email);
			
			if(existing_user.next()){
				JOptionPane.showMessageDialog(null, "Username "+loginName+" already exists!");
				saveToSQL = false;
			}
			if(loginName.equals("")||password.equals("")||email.equals(""))
			{
				JOptionPane.showMessageDialog(null, "Please fill out all info!");
				saveToSQL = false;
			}
			if(!(loginName.equals("")||password.equals("")||email.equals(""))) {
				if(loginName.equals(password)){
					JOptionPane.showMessageDialog(null, "Username and password should be different!");
					saveToSQL = false;
				}
				if(!matcher.matches()) {
					JOptionPane.showMessageDialog(null, "Please enter valid email");
				}
				if(!password.equals(confirmedPassword)) {
					JOptionPane.showMessageDialog(null, "Please regier with same password.");
					saveToSQL = false;
				}
			}
			
			if(saveToSQL&&matcher.matches()) {
				
				pst.setString(1, loginName);
	    		pst.setString(2, password);
	    		pst.setString(3, email);
	    		status = pst.executeUpdate();
			}
    		if(status==1) {
    			
    			JOptionPane.showMessageDialog(null, "Successful registered");
    			showPages jumpToThisPage = new showPages();
    			//jumpToThisPage.openPages("loginPage.fxml");
    			
    	    	jumpToThisPage.closePages(event);
    	    	
    	    	Stage loginStage = new Stage();
    	    	ViewLoginPage_Main loginPage = new ViewLoginPage_Main();
    	    	loginPage.start(loginStage);
    		}
    				
    	}
    	catch(Exception e) {System.out.println(e+"not found");}
	}

}
