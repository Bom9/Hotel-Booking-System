package application;

import javafx.scene.image.ImageView;

public class PageResult {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	
	private String hotel;
	private Integer rating;
	private String address;
	private Integer price;
	
	private ImageView image;
	

	
	public ImageView getImage() {
		return image;
	}

	public void setImage(ImageView image) {
		this.image = image;
	}

	public PageResult(ImageView image,String hotel,Integer rating,String address,Integer price) {
		this.image=image;
		this.hotel=hotel;
		this.rating=rating;
		this.address=address;
		this.price=price;
	}

	public String getHotel() {
		return hotel;
	}

	public void setHotel(String hotel) {
		this.hotel = hotel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	
	

}
