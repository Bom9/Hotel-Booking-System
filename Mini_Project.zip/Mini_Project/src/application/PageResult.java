package application;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class PageResult {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	
	private String hotel;
	private Integer rating;
	private String address;
	private Integer price;
	
	private ImageView image;
	private Button button;
	
	private Integer price2;
	
	private ImageView image2;
	private Button button2;
	

	
	public ImageView getImage() {
		return image;
	}

	public void setImage(ImageView image) {
		this.image = image;
	}

	public PageResult(ImageView image,ImageView image2,String hotel,Integer rating,String address,Integer price,Button button,Integer price2,Button button2) {
		this.image=image;
		this.hotel=hotel;
		this.rating=rating;
		this.address=address;
		this.price=price;
		this.button=button;
		this.button.setText("Book");
		
		this.price2=price2;
		this.image2=image2;
		this.button2=button2;
		this.button2.setText("Book");
	}

	public String getHotel() {
		return hotel;
	}

	public void setHotel(String hotel) {
		this.hotel = hotel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Button getButton() {
		return button;
	}

	public void setButton(Button button) {
		this.button = button;
	}

	public Integer getPrice2() {
		return price2;
	}

	public void setPrice2(Integer price2) {
		this.price2 = price2;
	}

	public ImageView getImage2() {
		return image2;
	}

	public void setImage2(ImageView image2) {
		this.image2 = image2;
	}

	public Button getButton2() {
		return button2;
	}

	public void setButton2(Button button2) {
		this.button2 = button2;
	}

	
	

}
