package application;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class adminPageSQL {
	Connection conn = null;
	
	
	public static Connection ConnectDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		
    		return conn;
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
	
	public static ObservableList<PageAdmin> getDatausers(){
		
		Connection conn = ConnectDB();
		ObservableList<PageAdmin> list = FXCollections.observableArrayList();
		try {
			
			PreparedStatement ps = conn.prepareStatement("select * from users");
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
	            
				list.add(new PageAdmin(rs.getInt("user_id"),rs.getString("username"),rs.getString("password"),rs.getString("email"),rs.getString("type")));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}
}
