package application;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class resultPageSQL {
	Connection conn = null;
	public static String hotel="";
	public void getHotel(String hotel) {
		this.hotel=hotel;
		System.out.println(hotel);
	}
	
	public static Connection ConnectDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/oop_project","root","Jianfa@1912");
    		return conn;
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
	
	public static ObservableList<PageResult> getDatausers(){
		Connection conn = ConnectDB();
		ControllerSearchPage search = new ControllerSearchPage();
		ObservableList<PageResult> list = FXCollections.observableArrayList();
		try {
			
			String statment = "select * from hotel_details where hotelName = '"+hotel+"'";
			//PreparedStatement ps = conn.prepareStatement("select * from hotel_details");
			PreparedStatement ps = conn.prepareStatement(statment);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				InputStream is = rs.getBinaryStream("king_image");
	            Image image = new Image(is, 250,300,false,true);
	            ImageView photo = new ImageView(image);
				list.add(new PageResult(photo, rs.getString("hotelName"), rs.getInt("rating"), rs.getString("location"), rs.getInt("price_king_room")));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
		try {
			
			String statment = "select * from hotel_details";
			//PreparedStatement ps = conn.prepareStatement("select * from hotel_details");
			PreparedStatement ps = conn.prepareStatement(statment);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				if(rs.getString("hotelName").equals(hotel))
					rs.next();
				InputStream is = rs.getBinaryStream("king_image");
	            Image image = new Image(is, 250,300,false,true);
	            ImageView photo = new ImageView(image);
				list.add(new PageResult(photo, rs.getString("hotelName"), rs.getInt("rating"), rs.getString("location"), rs.getInt("price_king_room")));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}
}
