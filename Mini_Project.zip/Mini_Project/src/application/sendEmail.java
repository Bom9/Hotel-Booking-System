package application;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class sendEmail
{
   public static void main(String[] args)
   {

   }
   String otp="";
   
   public void sendOTP(String email) {
	   
	   	  // send to who
	      String to = email;

	      // from who
	      String from = "jianfa122299@163.com";

	      //host
	      String host = "smtp.163.com";  //QQ email 

	      // get properties
	      Properties properties = System.getProperties();

	      // setting host
	      properties.setProperty("mail.smtp.host", host);

	      properties.put("mail.smtp.auth", "true");
	      // get session
	      Session session = Session.getDefaultInstance(properties,new Authenticator(){
	     public PasswordAuthentication getPasswordAuthentication(){
	      return new PasswordAuthentication("jianfa122299@163.com", "LXTBPTNZGJEDAKLV"); //name and code
	     }
	    });

	      try{
	         // craet MimeMessage 
	         MimeMessage message = new MimeMessage(session);

	         // Set From: 
	         message.setFrom(new InternetAddress(from));

	         // Set To: 
	         message.addRecipient(Message.RecipientType.TO,
	                                  new InternetAddress(to));

	         // Set Subject:
	         message.setSubject("Password Reset");
	         
	         for(int i=0;i<6;i++)
	         {
	        	 otp+=(int)(Math.random()*10);
	         }
	         String textSent = "Reset your password with the following otp: "+otp;
	         // 设置消息体
	         message.setText(textSent);

	         // send email
	         Transport.send(message);
	         //System.out.println("Sent message successfully");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
	   
   }
   
   public void sendConfirmedBooking(String email, String hotel, String date, String room, String price, String name) throws IOException {
	   // send to who
	      String to = email;

	      // from who
	      String from = "jianfa122299@163.com";

	      //host
	      String host = "smtp.163.com";  //QQ email 

	      // get properties
	      Properties properties = System.getProperties();

	      // setting host
	      properties.setProperty("mail.smtp.host", host);

	      properties.put("mail.smtp.auth", "true");
	      // get session
	      Session session = Session.getDefaultInstance(properties,new Authenticator(){
	     public PasswordAuthentication getPasswordAuthentication(){
	      return new PasswordAuthentication("jianfa122299@163.com", "LXTBPTNZGJEDAKLV"); //name and code
	     }
	    });

	      try{
	         // craet MimeMessage 
	         MimeMessage message = new MimeMessage(session);

	         // Set From: 
	         message.setFrom(new InternetAddress(from));

	         // Set To: 
	         message.addRecipient(Message.RecipientType.TO,
	                                  new InternetAddress(to));

	         // Set Subject:
	         message.setSubject("Confirmed Hotel Booking");
	         String textSent = "Dear %s, \nYou have Sucessfully booked %s at %s, from %s. Total paid %s.";
	         String text = String.format(textSent, name,room,hotel,date,price);
	         
	         
	         Multipart emailContent = new MimeMultipart();
	         MimeBodyPart textBodyPart = new MimeBodyPart();
	         textBodyPart.setText(text);
	         
	         MimeBodyPart pdfAttachment = new MimeBodyPart();
	         String file_name="C:\\Users\\jianf\\Documents\\SP\\Y3 22-23 Sem 2\\ET0706 OOP\\Project\\booking_details.pdf"; 
	         pdfAttachment.attachFile(file_name);
	         
	         emailContent.addBodyPart(textBodyPart);
	         emailContent.addBodyPart(pdfAttachment);
	         
	         message.setContent(emailContent);
	         
	         
	         
//	         String textSent = "Dear %s, you have Sucessfully booked %s at %s, from %s. Total paid %s.";
//	         String text = String.format(textSent, name,room,hotel,date,price);
	         // 设置消息体
	         //message.setText(text);
	         // send email
	         Transport.send(message);
	         System.out.println("Sent email successfully");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
   }
}