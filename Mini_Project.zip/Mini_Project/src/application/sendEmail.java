package application;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class sendEmail
{
   public static void main(String[] args)
   {

   }
   String otp="";
   
   public void sendOTP(String email) {
	   
	   	  // send to who
	      String to = email;

	      // from who
	      String from = "jianfa122299@163.com";

	      //host
	      String host = "smtp.163.com";  //QQ email 

	      // get properties
	      Properties properties = System.getProperties();

	      // setting host
	      properties.setProperty("mail.smtp.host", host);

	      properties.put("mail.smtp.auth", "true");
	      // get session
	      Session session = Session.getDefaultInstance(properties,new Authenticator(){
	     public PasswordAuthentication getPasswordAuthentication(){
	      return new PasswordAuthentication("jianfa122299@163.com", "LXTBPTNZGJEDAKLV"); //name and code
	     }
	    });

	      try{
	         // craet MimeMessage 
	         MimeMessage message = new MimeMessage(session);

	         // Set From: 
	         message.setFrom(new InternetAddress(from));

	         // Set To: 
	         message.addRecipient(Message.RecipientType.TO,
	                                  new InternetAddress(to));

	         // Set Subject:
	         message.setSubject("Password Reset");
	         
	         for(int i=0;i<6;i++)
	         {
	        	 otp+=(int)(Math.random()*10);
	         }
	         String textSent = "Reset your password with the following otp: "+otp;
	         // 设置消息体
	         message.setText(textSent);

	         // send email
	         Transport.send(message);
	         //System.out.println("Sent message successfully");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
	   
   }
}