package application;

import java.awt.event.ActionEvent;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class showPages {
	
	public void closePages(javafx.event.ActionEvent event) {
		try {
			Stage stage;
			Node n = (Node) event.getSource();
	    	stage = (Stage) n.getScene().getWindow();
			stage.close();
			
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}

}
