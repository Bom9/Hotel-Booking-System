package application;

import java.awt.event.ActionEvent;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class showPages {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
//	void openPages(String pageName) {
//		// TODO Auto-generated constructor stub
//		try {
//			FXMLLoader loader = new FXMLLoader
//					(getClass().getResource(pageName));
//			
//			AnchorPane root = (AnchorPane)loader.load(); //these two statments equavilent to the first statment
//			Stage search = new Stage(); 
//			Scene scene2 = new Scene(root,400,400);
//			search.initModality(Modality.APPLICATION_MODAL);
//			search.setScene(scene2);
//			
//			//ControllerSearchEnginePage controller = loader.getController();
//			//controller.transferData(name);
//			search.show();
//			}
//			catch(Exception e)
//			{
//				e.printStackTrace();
//			}
//	}
	public void closePages(javafx.event.ActionEvent event) {
		try {
			Stage stage;
			Node n = (Node) event.getSource();
	    	stage = (Stage) n.getScene().getWindow();
			stage.close();
			
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}

}
