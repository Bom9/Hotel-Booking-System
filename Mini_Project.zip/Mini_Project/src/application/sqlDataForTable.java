package application;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


interface sqlDataForTable {
	ObservableList getDatausers();
}

class searchResultVariables {
	InputStream kingIs;
    Image kingImage;
    ImageView kingPhoto;
    
    InputStream dKingIs;
    Image dKingImage;
    ImageView dKingphoto;
    
    public static String hotel="";
	public void getHotel(String hotel) {
		this.hotel=hotel;
		System.out.println(hotel);
	}
}

class getDataForAdmin implements sqlDataForTable{

	@Override
	public ObservableList<PageAdmin> getDatausers() {
		// TODO Auto-generated method stub
		Connection conn = sqlConnection.ConnectDB();
		ObservableList<PageAdmin> list = FXCollections.observableArrayList();
		
		try {
			
			PreparedStatement ps = conn.prepareStatement("select * from confirmedbooking");
			
			ResultSet rs = ps.executeQuery();
			int b =0;
			String blocked ="No";
			while(rs.next()) {
				String name = rs.getString("accountName");
				PreparedStatement ps2 = conn.prepareStatement("select * from login where name = ?");
				ps2.setString(1, name);
				ResultSet rs2 = ps2.executeQuery();
				rs2.next();
				if(rs2.getInt("blocklist")==1)
					blocked="Yes";
				
	            
				list.add(new PageAdmin(rs.getInt("id"),rs.getString("hotelName"),rs.getString("date"),
						rs.getString("guestName"),rs.getString("email"),rs.getString("mobile"),rs.getString("roomType"),
						rs.getString("price"),rs.getString("accountName"),rs.getString("accountEmail"),blocked));
				b++;
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}
	
}

class getDataForSearchResult extends searchResultVariables implements sqlDataForTable{

	@Override
	public ObservableList<PageResult> getDatausers() {
		// TODO Auto-generated method stub
		
		Connection conn = sqlConnection.ConnectDB();
		
		Button []button = new Button[3];
		ControllerResultPage result = new ControllerResultPage();
		
		
		ControllerSearchPage search = new ControllerSearchPage();
		ObservableList<PageResult> list = FXCollections.observableArrayList();
		try {
			
			String statment = "select * from hotel_details where hotelName = '"+hotel+"'";
			PreparedStatement ps = conn.prepareStatement(statment);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				getImage(rs);
	            
				list.add(new PageResult(kingPhoto, dKingphoto, rs.getString("hotelName"), rs.getInt("rating"), rs.getString("location"), rs.getInt("price_king_room"),result.button[0],rs.getInt("price_doulbe_king_room"),result.button[1]));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
		try {
			
			String statment = "select * from hotel_details";
			PreparedStatement ps = conn.prepareStatement(statment);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				if(rs.getString("hotelName").equals(hotel))
					rs.next();
				getImage(rs);
	            
				list.add(new PageResult(kingPhoto, dKingphoto, rs.getString("hotelName"), rs.getInt("rating"), rs.getString("location"), rs.getInt("price_king_room"),result.button[2],rs.getInt("price_doulbe_king_room"),result.button[3]));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}
	
	public void getImage(ResultSet rs) {
		try {
			kingIs = rs.getBinaryStream("king_image");
			dKingIs = rs.getBinaryStream("double_king_image");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        kingImage = new Image(kingIs, 250,300,false,true);
        kingPhoto = new ImageView(kingImage);
        
        
        dKingImage = new Image(dKingIs, 250,300,false,true);
        dKingphoto = new ImageView(dKingImage);
        
	}
	
}

