module Mini_Project {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires java.sql;
	requires java.desktop;
	requires org.controlsfx.controls;
	requires java.mail;
	
	
	opens application to javafx.graphics, javafx.fxml, java.mail, javafx.base;
	//exports application;
}
