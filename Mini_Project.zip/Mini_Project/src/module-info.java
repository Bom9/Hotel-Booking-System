module Mini_Project {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires java.sql;
	requires java.desktop;
	requires org.controlsfx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
